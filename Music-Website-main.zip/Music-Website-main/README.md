# Music-Website
Responsive Web Design using HTML and CSS 


Live Link: https://rajeevkrs.github.io/Music-Website/


(Desktop View)

![Screenshot (114)](https://github.com/rajeevkrS/Music-Website/assets/124420037/3c49a440-cde5-40d1-9b47-94085f988887)






(Tablet View)

![Screenshot (117)](https://github.com/rajeevkrS/Music-Website/assets/124420037/753ed573-309a-463a-b3f5-40a8bb597878)






(Mobile View)

![Screenshot (115)](https://github.com/rajeevkrS/Music-Website/assets/124420037/25ec34b3-94cc-4c6e-9771-dc0625232fbd)
